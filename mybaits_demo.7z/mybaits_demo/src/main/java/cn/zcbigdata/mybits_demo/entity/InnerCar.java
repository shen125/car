package cn.zcbigdata.mybits_demo.entity;

public class InnerCar {
    private int id;
    private String carType;
    private int keepType;
    private int engine;
    private int oil;
    private int tyre;
    private int wiper;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCarType() {
        return carType;
    }

    public void setCarType(String carType) {
        this.carType = carType;
    }

    public int getKeepType() {
        return keepType;
    }

    public void setKeepType(int keepType) {
        this.keepType = keepType;
    }

    public int getEngine() {
        return engine;
    }

    public void setEngine(int engine) {
        this.engine = engine;
    }

    public int getOil() {
        return oil;
    }

    public void setOil(int oil) {
        this.oil = oil;
    }

    public int getTyre() {
        return tyre;
    }

    public void setTyre(int tyre) {
        this.tyre = tyre;
    }

    public int getWiper() {
        return wiper;
    }

    public void setWiper(int wiper) {
        this.wiper = wiper;
    }

    @Override
    public String toString() {
        return "InnerCar{" +
                "id=" + id +
                ", carType='" + carType + '\'' +
                ", keepType=" + keepType +
                ", engine=" + engine +
                ", oil=" + oil +
                ", tyre=" + tyre +
                ", wiper=" + wiper +
                '}';
    }
}
