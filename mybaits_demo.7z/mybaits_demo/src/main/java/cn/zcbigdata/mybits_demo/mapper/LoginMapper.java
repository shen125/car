package cn.zcbigdata.mybits_demo.mapper;

import cn.zcbigdata.mybits_demo.entity.Login;

public interface LoginMapper {
    String selectByUsername(String username);
    void insert(Login login);
    int selectIdcard(String username);
    String selectByManger(String userName);
}
