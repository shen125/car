package cn.zcbigdata.mybits_demo.service.Impl;

import cn.zcbigdata.mybits_demo.entity.Regist;
import cn.zcbigdata.mybits_demo.mapper.RegistMapper;
import cn.zcbigdata.mybits_demo.service.RegistService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
@Service
public class RegistServiceImpl implements RegistService {

    @Resource
    RegistMapper registMapper;


    @Override
    public int selectCount() {
        return this.registMapper.selectCount();
    }

    @Override
    public List<Regist> selectAll(Integer page, Integer size) {
        page=(page-1)*size;
        return this.registMapper.selectAll(page,size);
    }

    @Override
    public int insert(Regist regist) {
        return this.registMapper.insert(regist);
    }

    @Override
    public int deleteById(Integer id) {
        return this.registMapper.deleteById(id);
    }

    @Override
    public int updateById(Regist regist) {
        return this.registMapper.updateById(regist);
    }


}
