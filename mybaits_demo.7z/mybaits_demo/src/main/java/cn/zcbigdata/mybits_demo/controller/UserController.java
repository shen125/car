package cn.zcbigdata.mybits_demo.controller;

import cn.zcbigdata.mybits_demo.Util.ObjtoLayJson;
import cn.zcbigdata.mybits_demo.entity.CarInfo;
import cn.zcbigdata.mybits_demo.entity.KeepInfo;
import cn.zcbigdata.mybits_demo.entity.Words;
import cn.zcbigdata.mybits_demo.service.CarInfoService;
import cn.zcbigdata.mybits_demo.service.KeepInfoService;
import cn.zcbigdata.mybits_demo.service.WordsService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
@CrossOrigin
@RequestMapping("/user")
public class UserController {

    @Resource
    private CarInfoService carInfoService;
    @Resource
    private KeepInfoService keepInfoService;
    @Resource
    private WordsService wordService;

    // 查询所有汽车信息
    @ResponseBody
    @RequestMapping(value = "/selectAll", method = RequestMethod.GET)
    public String selectAll(HttpServletRequest request, Model model) throws Exception {


        Integer idcard= (Integer) request.getSession().getAttribute("idCard");
        List<CarInfo> list = carInfoService.selectAll(idcard);

        String[] colums = { "id","idCard","carType","mileage","emissions","productDate","buyTime","keepNum"};
        String data = ObjtoLayJson.ListtoJson(list, colums);
        return data;
    }

    // 更新保养次数信息
    @ResponseBody
    @RequestMapping(value = "/updateKeepNum", method = RequestMethod.GET)
    public String updateKeepNum(HttpServletRequest request, Model model) throws Exception {

        String carType = request.getParameter("carType");

        CarInfo carInfo=new CarInfo();
        carInfo.setCarType(carType);
        Integer num=keepInfoService.selectKeepNum(carType);
        carInfo.setKeepNum(num);
        carInfoService.updateKeepNum(carInfo);
        String data = "[{\"status\":0}, {\"message\": \"成功\" }, {\"count\": 1000},"
                + "{\"rows\":{\"item\":[]}}]";

        return data;
    }

    // 增加汽车信息
    @ResponseBody
    @RequestMapping(value = "/addCar", method = RequestMethod.GET)
    public String addCar(HttpServletRequest request, Model model) throws Exception {

        String carType = request.getParameter("carType");
        String mileage = request.getParameter("mileage");
        String emissions = request.getParameter("emissions");
        String productDate = request.getParameter("productDate");
        String buyTime = request.getParameter("buyTime");

        Integer intmileage = Integer.valueOf(mileage);
        Integer intemissions = Integer.valueOf(emissions);

        HttpSession session=request.getSession();
        Object idcard = session.getAttribute("idCard");

        CarInfo carInfo=new CarInfo();
        carInfo.setIdCard((Integer) idcard);
        carInfo.setCarType(carType);
        carInfo.setMileage(intmileage);
        carInfo.setEmissions(intemissions);
        carInfo.setProductDate(productDate);
        carInfo.setBuyTime(buyTime);
        carInfo.setKeepNum(0);
        carInfoService.addCar(carInfo);
        String data = "[{\"status\":0}, {\"message\": \"成功\" }, {\"count\": 1000},"
                + "{\"rows\":{\"item\":[]}}]";

        return data;
    }

    // 删除车辆信息
    @ResponseBody
    @RequestMapping(value = "/deleteCar", method = RequestMethod.GET)
    public String deleteCar(HttpServletRequest request, Model model) throws Exception {


        String carType = request.getParameter("carType");
        carInfoService.deleteCar(carType);
        String data = "[{\"status\":0}, {\"message\": \"成功\" }, {\"count\": 1000},"
                + "{\"rows\":{\"item\":[]}}]";
        return data;
    }

    // 修改车辆信息
    @ResponseBody
    @RequestMapping(value = "/updateCarInfo", method = RequestMethod.GET)
    public String updateCarInfo(HttpServletRequest request, Model model) throws Exception {


        String carType = request.getParameter("carType");
        String mileage = request.getParameter("mileage");
        String emissions = request.getParameter("emissions");
        String productDate = request.getParameter("productDate");
        String buyTime = request.getParameter("buyTime");

        Integer intmileage = Integer.valueOf(mileage);
        Integer intemissions = Integer.valueOf(emissions);

        CarInfo carInfo=new CarInfo();
        carInfo.setCarType(carType);
        carInfo.setMileage(intmileage);
        carInfo.setEmissions(intemissions);
        carInfo.setProductDate(productDate);
        carInfo.setBuyTime(buyTime);

        carInfoService.updateCarInfo(carInfo);

        String data = "[{\"status\":0}, {\"message\": \"成功\" }, {\"count\": 1000},"
                + "{\"rows\":{\"item\":[]}}]";
        return data;
    }


    // 查询汽车保养信息
    @ResponseBody
    @RequestMapping(value = "/selectKeepInfo", method = RequestMethod.GET)
    public String selectKeepInfo(HttpServletRequest request, Model model) throws Exception {

        HttpSession session=request.getSession();
        Object idcard = session.getAttribute("idCard");

        List<KeepInfo> list = keepInfoService.selectKeepInfo((Integer) idcard);

        String[] colums = { "id","idCard","carType","keepDate"};
        String data = ObjtoLayJson.ListtoJson(list, colums);
        return data;
    }

    // 增加汽车保养信息
    @ResponseBody
    @RequestMapping(value = "/insertKeepInfo", method = RequestMethod.GET)
    public String insertKeepInfo(HttpServletRequest request, Model model) throws Exception {

        String carType = request.getParameter("carType");
        String keepDate = request.getParameter("keepDate");


        HttpSession session=request.getSession();
        Object idcard = session.getAttribute("idCard");

        KeepInfo keepInfo=new KeepInfo();
        keepInfo.setIdCard((Integer) idcard);
        keepInfo.setCarType(carType);
        keepInfo.setKeepDate(keepDate);


        keepInfoService.insertKeepInfo(keepInfo);
        String data = "[{\"status\":0}, {\"message\": \"成功\" }, {\"count\": 1000},"
                + "{\"rows\":{\"item\":[]}}]";

        return data;
    }

    // 删除车辆信息
    @ResponseBody
    @RequestMapping(value = "/deleteKeepInfo", method = RequestMethod.GET)
    public String deleteKeepInfo(HttpServletRequest request, Model model) throws Exception {


        String id = request.getParameter("id");
        Integer intid=Integer.valueOf(id);
        keepInfoService.deleteKeepInfo(intid);
        String data = "[{\"status\":0}, {\"message\": \"成功\" }, {\"count\": 1000},"
                + "{\"rows\":{\"item\":[]}}]";
        return data;
    }

    // 修改车辆保养信息
    @ResponseBody
    @RequestMapping(value = "/updateKeepInfo", method = RequestMethod.GET)
    public String updateKeepInfo(HttpServletRequest request, Model model) throws Exception {


        String id = request.getParameter("id");
        String carType = request.getParameter("carType");
        String keepDate = request.getParameter("keepDate");


        Integer intid = Integer.valueOf(id);


        KeepInfo keepInfo=new KeepInfo();
        keepInfo.setId(intid);
        keepInfo.setKeepDate(keepDate);

        keepInfo.setCarType(carType);

        keepInfoService.updateKeepInfo(keepInfo);

        String data = "[{\"status\":0}, {\"message\": \"成功\" }, {\"count\": 1000},"
                + "{\"rows\":{\"item\":[]}}]";
        return data;
    }

    // 插入留言信息
    @ResponseBody
    @RequestMapping(value = "/insertWords", method = RequestMethod.GET)
    public String insertWords(HttpServletRequest request, Model model) throws Exception {


        String content=request.getParameter("content");
        HttpSession session=request.getSession();
        Object name=session.getAttribute("username");
        Words words=new Words();
        words.setUserName((String) name);
        words.setContent(content);
        words.setFlag(0);
        wordService.insertWords(words);

        String data = "[{\"status\":0}, {\"message\": \"成功\" }, {\"count\": 1000},"
                + "{\"rows\":{\"item\":[]}}]";
        return data;
    }

    // 查看留言信息
    @ResponseBody
    @RequestMapping(value = "/selectWords", method = RequestMethod.GET)
    public String selectWords(HttpServletRequest request, Model model) throws Exception {

        HttpSession session=request.getSession();
        Object name=session.getAttribute("username");
        List<Words> list=wordService.selectWords((String) name);

        String[] colums={"id","userName","content","flag"};
        String data=ObjtoLayJson.ListtoJson(list,colums);

        return data;
    }

    // 查看公告
    @ResponseBody
    @RequestMapping(value = "/selectNotice", method = RequestMethod.GET)
    public String selectNotice(HttpServletRequest request, Model model) throws Exception {

        List<Words> list=wordService.selectNotice();
        String[] colums={"id","userName","content","flag"};
        String data=ObjtoLayJson.ListtoJson(list,colums);
        return data;
    }



}
