package cn.zcbigdata.mybits_demo.entity;

public class Login {
    private Integer id;
    private String userName;
    private  String password;
    private Integer idCard;

    public Integer getId() {
        return id;
    }

    public String getUserName() {
        return userName;
    }

    public String getPassword() {
        return password;
    }

    public Integer getIdCard() {
        return idCard;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setIdCard(Integer idCard) {
        this.idCard = idCard;
    }

    @Override
    public String toString() {
        return "Login{" +
                "id=" + id +
                ", userName='" + userName + '\'' +
                ", password='" + password + '\'' +
                ", idCard=" + idCard +
                '}';
    }
}
