package cn.zcbigdata.mybits_demo.mapper;

import cn.zcbigdata.mybits_demo.entity.KeepInfo;

import java.util.List;

public interface KeepInfoMapper {
    List<KeepInfo> selectKeepInfo(Integer idCard);
    void insertKeepInfo(KeepInfo keepInfo);
    void deleteKeepInfo(Integer id);
    void updateKeepInfo(KeepInfo keepInfo);
    Integer selectKeepNum(String cartype);
}
