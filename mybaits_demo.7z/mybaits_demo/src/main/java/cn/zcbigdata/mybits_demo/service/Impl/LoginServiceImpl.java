package cn.zcbigdata.mybits_demo.service.Impl;

import cn.zcbigdata.mybits_demo.entity.Login;
import cn.zcbigdata.mybits_demo.mapper.LoginMapper;
import cn.zcbigdata.mybits_demo.service.LoginService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
@Service
public class LoginServiceImpl implements LoginService {
    @Resource
    private LoginMapper loginMapper;


    @Override
    public String selectByUsername(String username) {
        return this.loginMapper.selectByUsername(username);
    }

    @Override
    public void insert(Login login) {
      this.loginMapper.insert(login);
    }

    @Override
    public int selectIdcard(String username) {
        return this.loginMapper.selectIdcard(username);
    }

    @Override
    public String selectByManger(String userName) {
        return this.loginMapper.selectByManger(userName);
    }
}
