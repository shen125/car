package cn.zcbigdata.mybits_demo.service.Impl;

import cn.zcbigdata.mybits_demo.entity.Words;
import cn.zcbigdata.mybits_demo.mapper.WordsMapper;
import cn.zcbigdata.mybits_demo.service.WordsService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
@Service
public class WordsServiceImpl implements WordsService {
    @Resource
    private WordsMapper wordsMapper;
    @Override
    public int selectWordCount() {
        return this.wordsMapper.selectWordCount();
    }

    @Override
    public List<Words> selectWordAll(int page, int size) {
        page=(page-1)*size;
        return this.wordsMapper.selectWordAll(page,size);
    }

    @Override
    public int updateWord(Words words) {
        return this.wordsMapper.updateWord(words);
    }

    @Override
    public int updateNotice(String content) {
        return this.wordsMapper.updateNotice(content);
    }

    @Override
    public void insertWords(Words words) {
        this.wordsMapper.insertWords(words);
    }

    @Override
    public List<Words> selectWords(String userName) {
        return this.wordsMapper.selectWords(userName);
    }

    @Override
    public List<Words> selectNotice() {
        return this.wordsMapper.selectNotice();
    }
}
