package cn.zcbigdata.mybits_demo.service.Impl;

import cn.zcbigdata.mybits_demo.entity.CarInfo;
import cn.zcbigdata.mybits_demo.mapper.CarInfoMapper;
import cn.zcbigdata.mybits_demo.service.CarInfoService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class CarInfoServiceImpl implements CarInfoService {
    @Resource
    private CarInfoMapper carInfoMapper;


    @Override
    public List<CarInfo> selectAll(Integer idcard) {
        return this.carInfoMapper.selectAll(idcard);
    }

    @Override
    public void addCar(CarInfo carInfo) {
        this.carInfoMapper.addCar(carInfo);
    }

    @Override
    public void deleteCar(String cartype) {
        this.carInfoMapper.deleteCar(cartype);
    }

    @Override
    public void updateCarInfo(CarInfo carInfo) {
        this.carInfoMapper.updateCarInfo(carInfo);
    }

    @Override
    public void updateKeepNum(CarInfo carInfo) {
        this.carInfoMapper.updateKeepNum(carInfo);
    }
}
