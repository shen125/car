package cn.zcbigdata.mybits_demo.service;

import cn.zcbigdata.mybits_demo.entity.CarInfo;

import java.util.List;

public interface CarInfoService {
    List<CarInfo> selectAll(Integer idcard);
    void addCar(CarInfo carInfo);
    void deleteCar(String cartype);
    void updateCarInfo(CarInfo carInfo);

    void updateKeepNum(CarInfo carInfo);

}
