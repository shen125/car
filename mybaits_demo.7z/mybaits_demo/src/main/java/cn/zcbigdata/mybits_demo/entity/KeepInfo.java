package cn.zcbigdata.mybits_demo.entity;

public class KeepInfo {
    Integer id;
    Integer idCard;
    String carType;
    String keepDate;

    public Integer getId() {
        return id;
    }

    public Integer getIdCard() {
        return idCard;
    }

    public String getCarType() {
        return carType;
    }

    public String getKeepDate() {
        return keepDate;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public void setIdCard(Integer idCard) {
        this.idCard = idCard;
    }

    public void setCarType(String carType) {
        this.carType = carType;
    }


    public void setKeepDate(String keepDate) {
        this.keepDate = keepDate;
    }

    @Override
    public String toString() {
        return "KeepInfo{" +
                "id=" + id +
                ", idCard=" + idCard +
                ", carType='" + carType + '\'' +
                ", keepDate='" + keepDate + '\'' +
                '}';
    }
}
