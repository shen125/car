package cn.zcbigdata.mybits_demo.entity;

public class Regist {
    private Integer id;
    private String userName;
    private String password;
    private Integer loginid;

    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }
    public String getUserName() {
        return userName;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public Integer getLoginid() {
        return loginid;
    }
    public void setLoginid(Integer loginid) {
        this.loginid = loginid;
    }
    @Override
    public String toString() {
        return "Regist [id=" + id + ", userName=" + userName + ", password=" + password + ", loginid=" + loginid + "]";
    }
}
