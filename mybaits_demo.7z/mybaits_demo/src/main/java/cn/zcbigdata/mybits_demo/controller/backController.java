package cn.zcbigdata.mybits_demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/index")
public class backController {
    //管理员
    @RequestMapping("/mangerLogin")
    public String mangerLogin(){
        return "mangerLogin";
    }

    @RequestMapping("/back")
    public String back(){
        return "back";
    }

    @RequestMapping("/InnerCarInfo")
    public String InnerCarInfo(){
        return "InnerCarInfo";
    }
    @RequestMapping("/keepType")
    public String keepType(){
        return "keepType";
    }
    @RequestMapping("/WordsSolve")
    public String WordsSolve(){
        return "WordsSolve";
    }

    //用户
    @RequestMapping("/userLogin")
    public String userLogin(){
        return "userLogin";
    }

    @RequestMapping("/register")
    public String register(){
        return "register";
    }
    @RequestMapping("/front")
    public String front(){
        return "front";
    }

    @RequestMapping("/CarInfo")
    public String CarInfo(){ return "CarInfo"; }

    @RequestMapping("/KeepInfo")
    public String KeepInfo(){ return "KeepInfo"; }

    @RequestMapping("/words")
    public String words(){ return "words"; }

    @RequestMapping("/notice")
    public String notice(){ return "notice"; }

}
