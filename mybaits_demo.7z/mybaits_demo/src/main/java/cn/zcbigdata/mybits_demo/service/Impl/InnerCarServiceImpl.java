package cn.zcbigdata.mybits_demo.service.Impl;

import cn.zcbigdata.mybits_demo.entity.InnerCar;
import cn.zcbigdata.mybits_demo.entity.KeepPlan;
import cn.zcbigdata.mybits_demo.mapper.InnerCarMapper;
import cn.zcbigdata.mybits_demo.service.InnerCarService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class InnerCarServiceImpl implements InnerCarService {
    @Resource
    private InnerCarMapper innerCarMapper;

    @Override
    public int selectCount() {
        return this.innerCarMapper.selectCount();
    }

    @Override
    public List<InnerCar> selectAll(int page, int size) {
        page=(page-1)*size;
        return this.innerCarMapper.selectAll(page,size);
    }


    @Override
    public int insert(InnerCar innerCar) {
        return this.innerCarMapper.insert(innerCar);
    }

    @Override
    public int updateById(InnerCar innerCar) {
        return this.innerCarMapper.updateById(innerCar);
    }

    @Override
    public int deleteById(int id) {
        return this.innerCarMapper.deleteById(id);
    }

    @Override
    public List<KeepPlan> selectKeepType() {
        return this.innerCarMapper.selectKeepType();
    }
}
