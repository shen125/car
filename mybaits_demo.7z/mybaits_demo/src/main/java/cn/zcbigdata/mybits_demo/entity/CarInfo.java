package cn.zcbigdata.mybits_demo.entity;

public class CarInfo {
    Integer id;
    Integer idCard;//身份证号
    String carType; // 车辆型号
    Integer mileage; //里程数
    Integer emissions;//发动机排量
    String productDate;//生产日期
    String buyTime;//购买时间
    Integer keepNum;//保养次数

    public Integer getId() {
        return id;
    }

    public Integer getIdCard() {
        return idCard;
    }

    public String getCarType() {
        return carType;
    }

    public Integer getMileage() {
        return mileage;
    }

    public Integer getEmissions() {
        return emissions;
    }

    public String getProductDate() {
        return productDate;
    }

    public String getBuyTime() {
        return buyTime;
    }

    public Integer getKeepNum() {
        return keepNum;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public void setIdCard(Integer idCard) {
        this.idCard = idCard;
    }

    public void setCarType(String carType) {
        this.carType = carType;
    }

    public void setMileage(Integer mileage) {
        this.mileage = mileage;
    }

    public void setEmissions(Integer emissions) {
        this.emissions = emissions;
    }

    public void setProductDate(String productDate) {
        this.productDate = productDate;
    }

    public void setBuyTime(String buyTime) {
        this.buyTime = buyTime;
    }

    public void setKeepNum(Integer keepNum) {
        this.keepNum = keepNum;
    }

    @Override
    public String toString() {
        return "CarInfo{" +
                "id=" + id +
                ", idCard=" + idCard +
                ", carType='" + carType + '\'' +
                ", mileage=" + mileage +
                ", emissions=" + emissions +
                ", productDate='" + productDate + '\'' +
                ", buyTime='" + buyTime + '\'' +
                ", keepNum=" + keepNum +
                '}';
    }
}
