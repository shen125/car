package cn.zcbigdata.mybits_demo.controller;

import cn.zcbigdata.mybits_demo.entity.Login;
import cn.zcbigdata.mybits_demo.service.LoginService;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@Controller
@CrossOrigin
@RequestMapping("/login")
public class LoginController {
    @Resource
    private LoginService loginService;


    // 用户注册
    @ResponseBody
    @RequestMapping(value = "/insert", method = RequestMethod.GET)
    public String insert(HttpServletRequest request, Model model) throws Exception {

        String username = request.getParameter("userName");
        String password = request.getParameter("password");
        String idCard =request.getParameter("idCard");
        Integer intid=Integer.valueOf(idCard);


        Login login=new Login();
        login.setUserName(username);
        login.setPassword(password);
        login.setIdCard(intid);
        loginService.insert(login);

        String data = "[{\"status\":0}, {\"message\": \"成功\" }, {\"count\": 1000},"
                + "{\"rows\":{\"item\":[{\"userName\":\"null\"},{\"password\":\"null\"}]}}]";


        return "{\"data\":0}";
    }

    // 用户登录
    @ResponseBody
    @RequestMapping(value = "/selectByUsername", method = RequestMethod.GET)
    public String selectByUsername(HttpServletRequest request, Model model) throws Exception {

        String username = request.getParameter("userName");
        String password = request.getParameter("password");
        String dbpassword = loginService.selectByUsername(username);
        if(password.equals(dbpassword)){

            Integer idCard=loginService.selectIdcard(username);
            HttpSession session=request.getSession();

            session.setAttribute("idCard",idCard);
            session.setAttribute("username",username);
            String data1="{\"data\":0}";
            return data1;
        }


        String data1="{\"data\":1}";
        return data1;
    }
    //管理员登录
    @RequestMapping(value = "/manger",method = RequestMethod.GET)
    @ResponseBody
    public String selectByManger(HttpServletRequest request){
        String userName=request.getParameter("userName");
        String password=request.getParameter("password");

        String result=loginService.selectByManger(userName);
        if(result.equals(password)){
            String data = "[{\"status\":0}, {\"message\": \"成功\" }, {\"count\": 1000},"
                    + "{\"rows\":{\"item\":[]}}]";
            return data;
        }
        String data = "[{\"status\":1}, {\"message\": \"失败\" }, {\"count\": 1000},"
                + "{\"rows\":{\"item\":[]}}]";
        return data;
    }

    //检查登录
    @ResponseBody
    @RequestMapping(value="/checkState", method=RequestMethod.GET,produces = "text/plain;charset=utf-8")
    public String checkState(HttpServletRequest request, Model model) throws Exception{
        HttpSession session=request.getSession();
        System.out.println("check的打印"+session.getAttribute("userName"));
        if(session.getAttribute("userName").equals("admin")) {
            return "{\"message\":66}";
        }else {
            return "{\"message\":99}";
        }
    }
}
