package cn.zcbigdata.mybits_demo.service;

import cn.zcbigdata.mybits_demo.entity.Words;

import java.util.List;

public interface WordsService {
    int selectWordCount();
    List<Words> selectWordAll(int page, int size);
    int updateWord(Words words);
    int updateNotice(String content);




    void insertWords(Words words);
    List<Words> selectWords(String userName);
    List<Words> selectNotice();
}
