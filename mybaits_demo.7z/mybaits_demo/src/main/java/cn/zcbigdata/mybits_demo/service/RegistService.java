package cn.zcbigdata.mybits_demo.service;

import cn.zcbigdata.mybits_demo.entity.Regist;

import java.util.List;

public interface RegistService {
    int selectCount();
    List<Regist> selectAll(Integer page,Integer size);
    int insert(Regist regist);
    int deleteById(Integer id);
    int updateById(Regist regist);
}
