package cn.zcbigdata.mybits_demo.service;

import cn.zcbigdata.mybits_demo.entity.Login;
import org.springframework.stereotype.Service;


public interface LoginService {
    String selectByUsername(String username);
    void insert(Login login);
    int selectIdcard(String username);
    String selectByManger(String userName);
}
