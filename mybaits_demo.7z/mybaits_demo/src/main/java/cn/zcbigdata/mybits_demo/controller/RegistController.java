package cn.zcbigdata.mybits_demo.controller;

import cn.zcbigdata.mybits_demo.Util.ObjtoLayJson;
import cn.zcbigdata.mybits_demo.entity.Regist;
import cn.zcbigdata.mybits_demo.service.RegistService;
import jdk.nashorn.internal.ir.RuntimeNode;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.List;

@Controller
@CrossOrigin
@RequestMapping("/regist")
public class RegistController {
    @Resource
    private RegistService registService;

    @RequestMapping(value="/selectCount",method = RequestMethod.GET)
    @ResponseBody
    public String selectCount(){
        int a=registService.selectCount();
        System.out.println("count:"+a);
        return "{\"count\":"+a+"}";
    }

    @RequestMapping(value="/selectAll",method= RequestMethod.GET)
    @ResponseBody
    public String selectAll(HttpServletRequest request) throws Exception {
        String pageString= request.getParameter("page");
        String sizeString=request.getParameter("limit");
        Integer page=Integer.valueOf(pageString);
        Integer size=Integer.valueOf(sizeString);
        System.out.println(page+"  "+size);
        List<Regist> regists=registService.selectAll(page,size);
        for (Regist regist:regists) {
            System.out.println(regist);
        }
        String[] colums={"id","userName","password","loginid"};
        String data= ObjtoLayJson.ListtoJson(regists,colums);
        return data;
    }
    @RequestMapping(value="/insert",method= RequestMethod.GET)
    @ResponseBody
    public String insert(HttpServletRequest request) {
        String userName=request.getParameter("userName");
        String password=request.getParameter("password");
        String loginid=request.getParameter("loginid");
        Integer intid=Integer.valueOf(loginid);
        Regist regist=new Regist();
        regist.setLoginid(intid);
        regist.setUserName(userName);
        regist.setPassword(password);
        int a=registService.insert(regist);
        String json = "";
        if(a==1) {
            json="{\"code\":200,\"message\":\"插入成功\"}";}
        else {
            json="{\"code\":0,\"message\":\"插入失败\"}";
        }
        return json;
    }

    @RequestMapping(value="/deleteById",method= RequestMethod.GET)
    @ResponseBody
    public String deleteById(HttpServletRequest request) {

        String id=request.getParameter("id");
        Integer intid=Integer.valueOf(id);

        int a=registService.deleteById(intid);
        String json = "";
        if(a==1) {
            json="{\"code\":200,\"message\":\"插入成功\"}";}
        else {
            json="{\"code\":0,\"message\":\"插入失败\"}";
        }
        return json;
    }

    @RequestMapping(value="/updateById",method= RequestMethod.GET)
    @ResponseBody
    public String updateById(HttpServletRequest request) {
        String userName=request.getParameter("userName");
        String password=request.getParameter("password");
        String loginid=request.getParameter("loginid");
        String id=request.getParameter("id");
        Integer intid=Integer.valueOf(id);
        Integer intlogin=Integer.valueOf(loginid);
        Regist regist=new Regist();
        regist.setId(intid);;
        regist.setLoginid(intlogin);
        regist.setUserName(userName);
        regist.setPassword(password);


        int a=registService.updateById(regist);
        String json = "";
        if(a==1) {
            json="{\"code\":200,\"message\":\"插入成功\"}";}
        else {
            json="{\"code\":0,\"message\":\"插入失败\"}";
        }
        return json;
    }
}
