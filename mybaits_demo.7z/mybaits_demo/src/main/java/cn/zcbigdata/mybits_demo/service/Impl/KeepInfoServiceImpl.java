package cn.zcbigdata.mybits_demo.service.Impl;

import cn.zcbigdata.mybits_demo.entity.KeepInfo;
import cn.zcbigdata.mybits_demo.mapper.KeepInfoMapper;
import cn.zcbigdata.mybits_demo.service.KeepInfoService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class KeepInfoServiceImpl implements KeepInfoService {
    @Resource
    private KeepInfoMapper keepInfoMapper;

    @Override
    public List<KeepInfo> selectKeepInfo(Integer idCard) {
        return this.keepInfoMapper.selectKeepInfo(idCard);
    }

    @Override
    public void insertKeepInfo(KeepInfo keepInfo) {
        this.keepInfoMapper.insertKeepInfo(keepInfo);
    }

    @Override
    public void deleteKeepInfo(Integer id) {
        this.keepInfoMapper.deleteKeepInfo(id);
    }

    @Override
    public void updateKeepInfo(KeepInfo keepInfo) {
        this.keepInfoMapper.updateKeepInfo(keepInfo);
    }

    @Override
    public Integer selectKeepNum(String cartype) {
        return this.keepInfoMapper.selectKeepNum(cartype);
    }
}
