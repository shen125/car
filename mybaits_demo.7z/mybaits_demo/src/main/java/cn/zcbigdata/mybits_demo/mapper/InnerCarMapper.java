package cn.zcbigdata.mybits_demo.mapper;

import cn.zcbigdata.mybits_demo.entity.InnerCar;
import cn.zcbigdata.mybits_demo.entity.KeepPlan;

import java.util.List;

public interface InnerCarMapper {
    int selectCount();
    List<InnerCar> selectAll(int page, int size);
    int insert(InnerCar innerCar);
    int updateById(InnerCar innerCar);
    int deleteById(int id);
    List<KeepPlan> selectKeepType();
}
