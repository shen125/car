package cn.zcbigdata.mybits_demo.controller;

import cn.zcbigdata.mybits_demo.Util.ObjtoLayJson;
import cn.zcbigdata.mybits_demo.entity.InnerCar;
import cn.zcbigdata.mybits_demo.entity.KeepPlan;
import cn.zcbigdata.mybits_demo.entity.Words;
import cn.zcbigdata.mybits_demo.service.InnerCarService;
import cn.zcbigdata.mybits_demo.service.WordsService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.constraints.NotNull;
import java.util.List;

@Controller
@CrossOrigin
@RequestMapping("/manger")
public class InnerCarController {
    @Resource
    private InnerCarService innerCarService;
    @Resource
    private WordsService wordsService;

    @RequestMapping(value="/selectCount",method = RequestMethod.GET)
    @ResponseBody
    public String selectCount(){
        int count=innerCarService.selectCount();
        return "{\"count\":"+count+"}";
    }

    //查看所有保养方案
    @RequestMapping(value = "/selectAll",method = RequestMethod.GET)
    @ResponseBody
    public  String selectAll(HttpServletRequest request, Model model) throws Exception {
        String pageString=request.getParameter("page");
        String limit=request.getParameter("limit");
        int page=Integer.valueOf(pageString);
        int size=Integer.valueOf(limit);
        List<InnerCar> list=innerCarService.selectAll(page,size);
        String[] colums={"id","carType","keepType","engine","oil","tyre","wiper"};
        String json= ObjtoLayJson.ListtoJson(list,colums);
        return json;
    }

    //新增保养方案
    @RequestMapping(value = "/insert",method = RequestMethod.GET)
    @ResponseBody
    public  String insert(HttpServletRequest request){
        String carType=request.getParameter("carType");
        String intString=request.getParameter("keepType");
        Integer keepType=Integer.valueOf(intString);
        InnerCar innerCar=new InnerCar();
        innerCar.setCarType(carType);
        innerCar.setKeepType(keepType);
        int a=innerCarService.insert(innerCar);
        if(a==1){
            String data = "[{\"status\":0}, {\"message\": \"成功\" }, {\"count\": 1000},"
                    + "{\"rows\":{\"item\":[]}}]";
            return data;
        }
        String data = "[{\"status\":1}, {\"message\": \"失败\" }, {\"count\": 1000},"
                + "{\"rows\":{\"item\":[]}}]";
        return data;
    }

    //修改保养方案
    @RequestMapping(value = "/update",method = RequestMethod.GET)
    @ResponseBody
    public  String update(HttpServletRequest request){
        String idString=request.getParameter("id");
        String carType=request.getParameter("carType");
        String intString=request.getParameter("keepType");
        Integer id=Integer.valueOf(idString);
        Integer keepType=Integer.valueOf(intString);
        InnerCar innerCar=new InnerCar();
        innerCar.setId(id);
        innerCar.setCarType(carType);
        innerCar.setKeepType(keepType);
        int a=innerCarService.updateById(innerCar);
        if(a==1){
            String data = "[{\"status\":0}, {\"message\": \"成功\" }, {\"count\": 1000},"
                    + "{\"rows\":{\"item\":[]}}]";
            return data;
        }
        String data = "[{\"status\":1}, {\"message\": \"失败\" }, {\"count\": 1000},"
                + "{\"rows\":{\"item\":[]}}]";
        return data;
    }

    //删除保养方案
    @RequestMapping(value = "/delete",method = RequestMethod.GET)
    @ResponseBody
    public  String delete(HttpServletRequest request){
        String idString=request.getParameter("id");

        int id=Integer.valueOf(idString);

        int a=innerCarService.deleteById(id);

        if(a==1){
            String data = "[{\"status\":0}, {\"message\": \"成功\" }, {\"count\": 1000},"
                    + "{\"rows\":{\"item\":[]}}]";
            return data;
        }
        String data = "[{\"status\":1}, {\"message\": \"失败\" }, {\"count\": 1000},"
                + "{\"rows\":{\"item\":[]}}]";
        return data;
    }

    //查看保养类型表
    @RequestMapping(value="/selectKeepType",method = RequestMethod.GET)
    @ResponseBody
    public String selectKeepType() throws Exception {
        List<KeepPlan> list=innerCarService.selectKeepType();
        String[] colums={"id","keepType","engine","oil","tyre","wiper"};
        String json= ObjtoLayJson.ListtoJson(list,colums);
        return json;
    }

    //查询未处理留言数量
    @RequestMapping(value = "/selectWordCount",method = RequestMethod.GET)
    @ResponseBody
    public String selectWordCount(){
        int count= wordsService.selectWordCount();
        return "{\"count\":"+count+"}";
    }

    //查看未处理留言信息
    @RequestMapping(value = "/selectWordAll",method = RequestMethod.GET)
    @ResponseBody
    public  String selectWordAll(HttpServletRequest request, Model model) throws Exception {
        String pageString=request.getParameter("page");
        String limit=request.getParameter("limit");
        int page=Integer.valueOf(pageString);
        int size=Integer.valueOf(limit);
        List<Words> list=wordsService.selectWordAll(page,size);
        String[] colums={"id","userName","content","flag"};
        String json= ObjtoLayJson.ListtoJson(list,colums);
        return json;
    }

    //管理员回复留言
    @RequestMapping(value = "/updateWord",method = RequestMethod.GET)
    @ResponseBody
    public  String updateWord(HttpServletRequest request){
        String idString=request.getParameter("id");
        String content=request.getParameter("content");
        Integer id=Integer.valueOf(idString);
        Words words=new Words();
        words.setId(id);
        words.setContent(content);
        int a=wordsService.updateWord(words);
        if(a==1){
            String data = "[{\"status\":0}, {\"message\": \"成功\" }, {\"count\": 1000},"
                    + "{\"rows\":{\"item\":[]}}]";
            return data;
        }
        String data = "[{\"status\":1}, {\"message\": \"失败\" }, {\"count\": 1000},"
                + "{\"rows\":{\"item\":[]}}]";
        return data;
    }

    //管理员发布公告
    @RequestMapping(value = "/updateNotice",method = RequestMethod.GET)
    @ResponseBody
    public  String updateNotice(HttpServletRequest request){

        String content=request.getParameter("content");
        int a=wordsService.updateNotice(content);
        if(a==1){
            String data = "[{\"status\":0}, {\"message\": \"成功\" }, {\"count\": 1000},"
                    + "{\"rows\":{\"item\":[]}}]";
            return data;
        }
        String data = "[{\"status\":1}, {\"message\": \"失败\" }, {\"count\": 1000},"
                + "{\"rows\":{\"item\":[]}}]";
        return data;
    }

}
